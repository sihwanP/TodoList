export default function App() {
  return <div>Hello, React.JS!</div>;
}
